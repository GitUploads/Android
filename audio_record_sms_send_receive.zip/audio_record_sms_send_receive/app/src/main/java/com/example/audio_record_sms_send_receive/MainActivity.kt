package com.example.audio_record_sms_send_receive

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var audio_record = findViewById<Button>(R.id.audio_record)
        var sms_send_receive = findViewById<Button>(R.id.sms_send_receive)

        audio_record.setOnClickListener {
            startActivity(Intent(this,RecordAudio::class.java))
        }

        sms_send_receive.setOnClickListener {
            startActivity(Intent(this,SMSSendReceive::class.java))
        }
    }
}