package com.example.customcontentprovider

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    lateinit var ed1 : EditText
    lateinit var ed2 : EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ed1 = findViewById(R.id.ed1)
        ed2 = findViewById(R.id.ed2)


        var rs = contentResolver.query(AcronymProvider.CONTENT_URI, arrayOf(AcronymProvider._ID,AcronymProvider.NAME,AcronymProvider.MEANING),null,null,null)

        var btn_next = findViewById<Button>(R.id.button)
        btn_next.setOnClickListener {
            if(rs?.moveToNext()!!)
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))

            }else if(rs!!.moveToFirst())
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))
            }
        }

        var btn_prev = findViewById<Button>(R.id.button2)
        btn_prev.setOnClickListener {
            if(rs?.moveToPrevious()!!)
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))

            }else if(rs!!.moveToLast())
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))
            }
        }

        var btn_first = findViewById<Button>(R.id.button3)
        btn_first.setOnClickListener {
            if(rs?.moveToFirst()!!)
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))

            }
        }

        var btn_last = findViewById<Button>(R.id.button4)
        btn_last.setOnClickListener {
            if(rs?.moveToLast()!!)
            {
                ed1.setText(rs!!.getString(1))
                ed2.setText(rs!!.getString(2))

            }
        }

        var btn_insert = findViewById<Button>(R.id.button5)

        btn_insert.setOnClickListener {
            var cv = ContentValues()
            cv.put(AcronymProvider.NAME,ed1.text.toString())
            cv.put(AcronymProvider.MEANING,ed2.text.toString())
            contentResolver.insert(AcronymProvider.CONTENT_URI,cv)
            rs = contentResolver.query(AcronymProvider.CONTENT_URI, arrayOf(AcronymProvider._ID,AcronymProvider.NAME,AcronymProvider.MEANING),null,null,null)
            clear()

        }

        var btn_update = findViewById<Button>(R.id.button6)
        btn_update.setOnClickListener {
            var cv = ContentValues()
            cv.put(AcronymProvider.MEANING,ed2.text.toString())
            contentResolver.update(AcronymProvider.CONTENT_URI,cv,"name=?", arrayOf(ed1.text.toString()))
            rs = contentResolver.query(AcronymProvider.CONTENT_URI, arrayOf(AcronymProvider._ID,AcronymProvider.NAME,AcronymProvider.MEANING),null,null,null)
            clear()
        }

        var btn_delete = findViewById<Button>(R.id.button7)

        btn_delete.setOnClickListener {
            contentResolver.delete(AcronymProvider.CONTENT_URI,"name=?",arrayOf(ed1.text.toString()))
            rs = contentResolver.query(AcronymProvider.CONTENT_URI, arrayOf(AcronymProvider._ID,AcronymProvider.NAME,AcronymProvider.MEANING),null,null,null)
            clear()
        }

        var btn_clear = findViewById<Button>(R.id.button8)
        btn_clear.setOnClickListener {
            clear()
        }

        var btn_view_all = findViewById<Button>(R.id.button9)

        btn_view_all.setOnClickListener {
            startActivity(Intent(applicationContext,ViewAllActivity::class.java))
        }




    }

    private fun clear() {
        ed1.setText("")
        ed2.setText("")
        ed1.requestFocus()
    }
}