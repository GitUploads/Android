package com.example.drawer_framebyframeanimation

import android.graphics.drawable.AnimationDrawable
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FrameByFrameFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class FrameByFrameFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var v = inflater.inflate(R.layout.fragment_frame_by_frame, container, false)

        var iv = v.findViewById<ImageView>(R.id.imageView)
        var ad = AnimationDrawable()
        var f1 = resources.getDrawable(R.drawable.frame_one)
        var f2 = resources.getDrawable(R.drawable.frame_two)
        var f3 = resources.getDrawable(R.drawable.frame_three)
        var f4 = resources.getDrawable(R.drawable.frame_four)
        var f5 = resources.getDrawable(R.drawable.frame_five)
        var f6 = resources.getDrawable(R.drawable.frame_six)


        ad.addFrame(f1,200)
        ad.addFrame(f2,200)
        ad.addFrame(f3,200)
        ad.addFrame(f4,200)
        ad.addFrame(f5,200)
        ad.addFrame(f6,200)
       

        iv.background = ad

        ad.start()

        return v
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FrameByFrameFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FrameByFrameFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}