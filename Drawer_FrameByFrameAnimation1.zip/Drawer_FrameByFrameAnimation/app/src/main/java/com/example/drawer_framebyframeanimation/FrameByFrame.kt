package com.example.drawer_framebyframeanimation

import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FrameByFrame : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_frame_by_frame)

        var ad = AnimationDrawable()
        var f1 = resources.getDrawable(R.drawable.frame_one)
        var f2 = resources.getDrawable(R.drawable.frame_two)
        var f3 = resources.getDrawable(R.drawable.frame_three)
        var f4 = resources.getDrawable(R.drawable.frame_four)
        var f5 = resources.getDrawable(R.drawable.frame_five)
        var f6 = resources.getDrawable(R.drawable.frame_six)

        ad.addFrame(f1,200)
        ad.addFrame(f2,200)
        ad.addFrame(f3,200)
        ad.addFrame(f4,200)
        ad.addFrame(f5,200)
        ad.addFrame(f6,200)

        ad.start()
    }
}