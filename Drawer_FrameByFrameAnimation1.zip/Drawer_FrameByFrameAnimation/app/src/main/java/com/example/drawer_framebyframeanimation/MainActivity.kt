package com.example.drawer_framebyframeanimation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.ListView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout

class MainActivity : AppCompatActivity() {
    lateinit var toggle : ActionBarDrawerToggle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var lv = findViewById<ListView>(R.id.listview)
        var drawer = findViewById<DrawerLayout>(R.id.drawer)
        var frame = findViewById<FrameLayout>(R.id.frame)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        toggle = ActionBarDrawerToggle(this,drawer,R.string.open,R.string.close)

        drawer.setDrawerListener(toggle)
        toggle.syncState()

        var data = arrayOf("First Fragment","Second Fragment")

        var adapter = ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,data)
        lv.adapter = adapter

        lv.setOnItemClickListener { adapterView, view, i, l ->
            drawer.closeDrawers()
            when(i){
                0 -> supportFragmentManager.beginTransaction().replace(R.id.frame,Fragment_one()).commit()
                1 -> supportFragmentManager.beginTransaction().replace(R.id.frame,FrameByFrameFragment()).commit()
            }
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(toggle.onOptionsItemSelected(item))
            return true
        return super.onOptionsItemSelected(item)
    }
}