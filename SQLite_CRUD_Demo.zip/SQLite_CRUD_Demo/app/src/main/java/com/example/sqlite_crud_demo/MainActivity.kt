package com.example.sqlite_crud_demo

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    lateinit var etName : EditText
    lateinit var etCity : EditText
    lateinit var adapter : SimpleCursorAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var btnInsert = findViewById<Button>(R.id.btnInsert)
        var btnUpdate = findViewById<Button>(R.id.btnUpdate)
        var btnDelete = findViewById<Button>(R.id.btnDelete)
        var btnClear = findViewById<Button>(R.id.btnClear)
        var btnPrev = findViewById<Button>(R.id.btnPrev)
        var btnNext = findViewById<Button>(R.id.btnNext)
        var btnFirst = findViewById<Button>(R.id.btnFirst)
        var btnLast = findViewById<Button>(R.id.btnLast)
        var btnShowAll = findViewById<Button>(R.id.btnShowAll)

        var sv = findViewById<SearchView>(R.id.searchView)
        var lv = findViewById<ListView>(R.id.listView)


        etName = findViewById(R.id.etName)
        etCity = findViewById(R.id.etCity)

        var cv = ContentValues()

        var helper = MyHelper(applicationContext)
        var db = helper.writableDatabase

        var rs = db.rawQuery("SELECT ROLLNUM _id,NAME,CITY FROM STUDENT",null)

        btnInsert.setOnClickListener {
            cv.put("NAME",etName.text.toString())
            cv.put("CITY",etCity.text.toString())
            db.insert("STUDENT",null,cv)
            clear()
        }


        btnNext.setOnClickListener {
            if(rs.moveToNext())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }
            else if(rs.moveToFirst())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }
        }
        btnPrev.setOnClickListener {
            if(rs.moveToPrevious())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }
            else if(rs.moveToLast())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }
        }

        btnClear.setOnClickListener {
            clear()
        }

        btnUpdate.setOnClickListener {
            cv.put("NAME",etName.text.toString())
            cv.put("CITY",etCity.text.toString())
            db.update("STUDENT",cv,"ROLLNUM=?", arrayOf(rs.getString(0)))
            rs = db.rawQuery("SELECT ROLLNUM _id,NAME,CITY FROM STUDENT",null)
            clear()
        }

        btnDelete.setOnClickListener {
            db.delete("STUDENT","ROLLNUM=?", arrayOf(rs.getString(0)))
            rs = db.rawQuery("SELECT ROLLNUM _id,NAME,CITY FROM STUDENT",null)
            if(rs.moveToFirst())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }

        }
        btnFirst.setOnClickListener {
            if(rs.moveToFirst())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }

        }
        btnLast.setOnClickListener {
            if(rs.moveToLast())
            {
                etName.setText( rs.getString(1))
                etCity.setText( rs.getString(2))
            }
        }

        btnShowAll.setOnClickListener {
            sv.isIconified = false
            sv.queryHint = "Search from ${rs.count} records"

            adapter = SimpleCursorAdapter(applicationContext,
                android.R.layout.simple_list_item_2,
                rs,
                arrayOf("NAME","CITY"),
                intArrayOf(android.R.id.text1,android.R.id.text2),
                0)
            lv.adapter = adapter


        }
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                rs = db.rawQuery("SELECT ROLLNUM _id,NAME,CITY FROM STUDENT WHERE NAME LIKE '%$p0%' ",null)
                adapter.changeCursor(rs)
                return false
            }

        })

    }

    private fun clear() {
        etName.setText("")
        etCity.setText("")
        etName.requestFocus()
    }
}